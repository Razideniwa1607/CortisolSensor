package com.example.serius;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;



public class second extends AppCompatActivity{

    // inisalisasi array pada spinner
    private String[] gender = {" ","Laki-Laki","Perempuan"};
    private String[] metode = {" ","Acid","Porter","Prusian","Blue",
            };
    Button Lanjut;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data);
        final Spinner List = findViewById(R.id.sp);
        final Spinner List1= findViewById(R.id.sp2);
        Lanjut= findViewById(R.id.lanjut);


        final ArrayAdapter<String> gender1 = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,gender);
        final ArrayAdapter<String> metode1 = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,metode);


       List.setAdapter(gender1);
        List1.setAdapter(metode1);



        List.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(),gender1.getItem(i)+"telah dipilih", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(getApplicationContext(),"Tidak Ada Item Yang Dipilih", Toast.LENGTH_LONG).show();
            }
        });
        List1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(),metode1.getItem(i)+"telah dipilih", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(getApplicationContext(),"Tidak Ada Item Yang Dipilih", Toast.LENGTH_SHORT).show();
            }
        });
        Lanjut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openthird();

            }
        });
    }
    public void openthird(){
       Intent intent= new Intent(this,Hasil.class);
       startActivity(intent);
    }
}