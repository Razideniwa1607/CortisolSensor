package com.example.serius;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
        Button open;
        Button analisis;
        String GAMBAR = "gambar";
    public static final int CAMERA_REQUEST = 9999;

        @Override
        protected void onCreate (Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            imageView = findViewById(R.id.image_view);
            open = findViewById((R.id.bt_open));
            analisis = findViewById(R.id.an_open);


            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) !=
                    PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{
                                Manifest.permission.CAMERA
                        },
                        100);
            }

            open.setOnClickListener(new View.OnClickListener() {//Fungsi dijalankan setelah button dipencet
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                    startActivityForResult(intent,CAMERA_REQUEST);


                    }





            });
            analisis.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    opensecond();
                }
            });


        }

         public void opensecond(){
             Intent intent= new Intent(this,second.class);
             startActivity(intent);
            }






        @Override
        protected void onActivityResult ( int requestCode, int resultCode,  Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST  ) {

            Bitmap captureImage = (Bitmap) data.getExtras().get("data");
            Log.d("main activity ",captureImage.toString());
            imageView.setImageBitmap(captureImage);
            Intent intent= new Intent(this,Hasil.class);
            intent.putExtra(GAMBAR,captureImage);
            startActivity(intent);

            }



        }


    }








