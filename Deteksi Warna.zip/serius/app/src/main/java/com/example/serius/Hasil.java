package com.example.serius;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.hardware.camera2.CameraManager;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;
import java.io.IOException;

public class Hasil extends AppCompatActivity {
    ImageView imageView2;
    TextView mColorValues;
    Bitmap bitmap;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hasil);
        imageView2 =  findViewById(R.id.image_view2);
        imageView2.setDrawingCacheEnabled(true);
        imageView2.buildDrawingCache(true);
        mColorValues= findViewById(R.id.displayvalues);
        MainActivity gambar = new MainActivity();
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            Bitmap image = (Bitmap) extras.get(gambar.GAMBAR);
            Log.d("hasil",image.toString());
            imageView2.setImageBitmap(image);
        }





        imageView2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction()==MotionEvent.ACTION_DOWN ){
                    bitmap=imageView2.getDrawingCache();
                    int pixel= bitmap.getPixel((int)event.getX(), (int)event.getY());
                    int r= Color.red(pixel);
                    int g= Color.green(pixel);
                    int b= Color.blue(pixel);
                    mColorValues.setText("RGB="+r+","+g+","+b+" ");
                }
                return true;
            }
        });









        }

    }

